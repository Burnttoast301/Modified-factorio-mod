data.raw["equipment-grid"]['spidertron-equipment-grid'].width = 200
data.raw["equipment-grid"]['spidertron-equipment-grid'].height = 100

data.raw["spider-vehicle"]['spidertron'].inventory_size = 500
